<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="de" xml:lang="de">
<head>
<title>Unterkunftsdatenbank</title>
<link rel="stylesheet" type="text/css" href="../bergsport.css" />
<script src="/webfont/M2682396/M2682396.js" type="text/javascript"></script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<p class="center"><img alt="Hotel" src="../bergsport/images/ferienwohnungen1.gif" border="0" /></p><p>Wenn Sie eine Liste mit allen Ferienwohnungen/Ferienhäusern
aus Sankt Andreasberg erhalten wollen, drücken Sie auf die
Schaltfläche &raquo;Alle anzeigen&laquo;. Eine detailierte Abfrage mit Ihren
Wünschen können Sie direkt darunter durchführen.</p><form method="post" action="/cgi-bin/ferienwohnung-haus-alle.pl" enctype="multipart/form-data"><input type="submit" name="Alle anzeigen" value="Alle anzeigen" /></form><p class="center"><b>Suchabfrage Ferienwohnung/Ferienhaus</b></p><p>Meine Ferienwohnung/Ferienhaus in Sankt Andreasberg sollte über folgende Ausstattung/Eigenschaften verfügen:</p><form method="post" action="/cgi-bin/ferienwohnung-haus-antwort.pl" enctype="multipart/form-data"><table width="40%" cellpadding="5" align="center" border="0"><tr><td><img src='../bergsport/images/personen.gif' alt='Personenanzahl'></td><td>Personenanzahl</td><td><select name='personen'>