<?xml version="1.0" encoding="iso-8859-1"?>
<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US" xml:lang="en-US"><head><title>Untitled Document</title>
</head><body text="black" bgcolor="white"><style type="text/css">
/*<![CDATA[*/
 body {
  background-color: #FFFFFF;
 }
 p.abs					{ margin-top:120px; }
 
 p.keinabs				{ margin-top:-10pt;
 					margin-left:-10pt;
 					margin-right:-10pt; }
 
 p.navi					{ margin-top:50px; }
 
 p,blockquote,caption,dl,table		{ font-size:10pt;
 					line-height:12pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black; }
 
 p.gro					{ font-size:14pt;
 					line-height:16pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black; }
 
 li.gro					{ font-size:14pt;
 					line-height:16pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black; }
 
 table.gro				{ font-size:14pt;
 					line-height:16pt;
 					font-family:Helvetica,Arial,sans-serif;
 					margin-left:0pt;
 					color:black; }
 
 p.date					{ font-size:10pt;
 					font-style:italic;
 					line-height:12pt;
 					font-family:Helvetica,Arial,sans-serif;
 					text-align:center;
 					color:black; }
 
 p.center				{ text-align:center; }
 
 li					{ font-size:10pt;
 					line-height:12pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black;
 					margin-bottom:10pt; }
 
 h1					{ font-size:14pt;
 					text-align:center;
 					font-weight:bold;
 					margin-right:20px;
 					line-height:16pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black; }
 
 h2					{ font-size:12pt;
 					text-align:center;
 					font-weight:bold;
 					margin-right:20px;
 					line-height:14pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black; }
 
 a.ueber:link				{ text-decoration:none; 
 					font-size:10pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold; 
 					color:black; }
  
 a.ueber:visited				{ text-decoration:none;
 					font-size:10pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;						font-weight:bold; 
 					color:black; }
 
 a.ueber:hover				{ text-decoration:none; 
 					font-size:10pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold;
 					color:red; }
 
 a.ueber:active				{ text-decoration:none; 
 					font-size:10pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold; 
 					color:red; }
 
 a.weiss:link				{ text-decoration:none; 
 					font-size:12pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold; 
 					color:white; }
  
 a.weiss:visited				{ text-decoration:none;
 					font-size:12pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;						font-weight:bold; 
 					color:white; }
 
 a.weiss:hover				{ text-decoration:none; 
 					font-size:12pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold;
 					color:red; }
 
 a.weiss:active				{ text-decoration:none; 
 					font-size:12pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold; 
 					color:red; }
 
 a:link					{ text-decoration:none; 
 					font-weight:bold; 
 					color:blue; }
  
 a:visited				{ text-decoration:none; 
 					font-weight:bold; 
 					color:blue; }
 
 a:hover					{ text-decoration:none; 
 					font-weight:bold;
 					color:red; }
 
 a:active				{ text-decoration:none; 
 					font-weight:bold; 
 					color:red; }
 
 .tooltip				{
 					position: absolute;
 					display: none;
 					font-family:Helvetica,Arial,sans-serif;
 					background-color: #FFFFFF; }
 
 .tooltip2				{
 					position: absolute;
 					display: none;
 					font-family:Helvetica,Arial,sans-serif;
 					background-color: #FFFFFF;
 					border-width: 1px;
 					border-style: solid;
 					border-color: #000000;
 					padding: 2px; }
 
 .tooltip2				.head{
 					font-family:Helvetica,Arial,sans-serif;
 					background-color: #009933;
 					color: white;
 					font-weight: bold;
 					padding: 2px; }
 
 .tooltip2				.content{
 					font-family:Helvetica,Arial,sans-serif;
 					color: 000066;
 					font-size: 10px;
 					border-size: 4px; }
 
 .tooltip2				.content td{
 					font-family:Helvetica,Arial,sans-serif;
 					width: 50%;
 					font-size: 10px;
 					text-align: center; }
 
 
 
 
 
/*]]>*/
</style><h1>Veranstaltungen am 08.08.2007
</h1><p class="center"><img src="http://www.sankt-andreasberg.com/andreasberg/images/telemarker.gif" alt="Langlauf" border="0"></p><p>Wir bieten Ihnen heute 5 Veranstaltungen:</p><table align="center" border="0" cellpadding="5" cellspacing="0"><tr><td align="center"><strong>10.00 Uhr:</strong></td><td><a href="http://www.sankt-andreasberg.com/cgi-bin/veran-heute.pl?id=4620">Felsklettern (Action im Harz)</a></td></tr><tr><td align="center"><strong>11.00 Uhr:</strong></td><td><a href="http://www.sankt-andreasberg.com/cgi-bin/veran-heute.pl?id=3390">F�hrung Grube Samson</a></td></tr><tr><td align="center"><strong>13.45 Uhr:</strong></td><td><a href="http://www.sankt-andreasberg.com/cgi-bin/veran-heute.pl?id=2848">F�hrung Catharina Neufang</a></td></tr><tr><td align="center"><strong>14.30 Uhr:</strong></td><td><a href="http://www.sankt-andreasberg.com/cgi-bin/veran-heute.pl?id=3391">F�hrung Grube Samson</a></td></tr><tr><td align="center"><strong>16.00 Uhr:</strong></td><td><a href="http://www.sankt-andreasberg.com/cgi-bin/veran-heute.pl?id=4625">Schatzsuche (Action im Harz)</a></td></tr></table><p class="center"><strong>Veranstaltungssuche</strong></p><p>Hier k&ouml;nnen Sie gezielt nach einer Veranstaltung in einem bestimmten Zeitraum suchen. Bitte ver&auml;ndern Sie die Datumsfelder entsprechend.</p><form action="http://www.sankt-andreasberg.com/cgi-bin/veran-zeitraum.pl">
<table align="center" border="0" cellpadding="5">
<tr>
<td>von: Tag</td><td><select name="tag">
<option value="01">1</option>
<option value="02">2</option>
<option value="03">3</option>
<option value="04">4</option>
<option value="05">5</option>
<option value="06">6</option>
<option value="07">7</option>
<option value="08">8</option>
<option value="09">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
<option value="08
" selected>08
</option>
</select></td>
<td>Monat</td><td><select name="monat">
<option value="01">1</option>
<option value="02">2</option>
<option value="03">3</option>
<option value="04">4</option>
<option value="05">5</option>
<option value="06">6</option>
<option value="07">7</option>
<option value="08">8</option>
<option value="09">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="08
" selected>08
</option>
</select></td>
<td>Jahr</td><td><select name="jahr">
<option value="2005">2005</option>
<option value="2006">2006</option>
<option value="2007">2007</option>
<option value="2008">2008</option>
<option value="2009">2009</option>
<option value="2007
" selected>2007
</option>
</select></td>
</tr>
<tr>
<td>bis: Tag</td><td><select name="bistag">
<option value="01">1</option>
<option value="02">2</option>
<option value="03">3</option>
<option value="04">4</option>
<option value="05">5</option>
<option value="06">6</option>
<option value="07">7</option>
<option value="08">8</option>
<option value="09">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
<option value="31" selected>31</option>
</select></td>
<td>Monat</td><td><select name="bismonat">
<option value="01">1</option>
<option value="02">2</option>
<option value="03">3</option>
<option value="04">4</option>
<option value="05">5</option>
<option value="06">6</option>
<option value="07">7</option>
<option value="08">8</option>
<option value="09">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="08
" selected>08
</option>
</select></td>
<td>Jahr</td><td><select name="bisjahr">
<option value="2005">2005</option>
<option value="2006">2006</option>
<option value="2007">2007</option>
<option value="2008">2008</option>
<option value="2009">2009</option>
<option value="2007
" selected>2007
</option>
</select></td>
</tr>
</table>
<p></p>
<p></p>
<input type="submit" value="Anfrage starten"></input>
</form></body></html>