<?xml version="1.0" encoding="iso-8859-1"?>
<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US" xml:lang="en-US"><head><title>Untitled Document</title>
</head><body text="black" bgcolor="white"><style type="text/css">
/*<![CDATA[*/
 body {
  background-color: #FFFFFF;
 }
 p.abs					{ margin-top:120px; }
 
 p.keinabs				{ margin-top:-10pt;
 					margin-left:-10pt;
 					margin-right:-10pt; }
 
 p.navi					{ margin-top:50px; }
 
 p,blockquote,caption,dl,table		{ font-size:10pt;
 					line-height:12pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black; }
 
 p.gro					{ font-size:14pt;
 					line-height:16pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black; }
 
 li.gro					{ font-size:14pt;
 					line-height:16pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black; }
 
 table.gro				{ font-size:14pt;
 					line-height:16pt;
 					font-family:Helvetica,Arial,sans-serif;
 					margin-left:0pt;
 					color:black; }
 
 p.date					{ font-size:10pt;
 					font-style:italic;
 					line-height:12pt;
 					font-family:Helvetica,Arial,sans-serif;
 					text-align:center;
 					color:black; }
 
 p.center				{ text-align:center; }
 
 li					{ font-size:10pt;
 					line-height:12pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black;
 					margin-bottom:10pt; }
 
 h1					{ font-size:14pt;
 					text-align:center;
 					font-weight:bold;
 					margin-right:20px;
 					line-height:16pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black; }
 
 h2					{ font-size:12pt;
 					text-align:center;
 					font-weight:bold;
 					margin-right:20px;
 					line-height:14pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black; }
 
 a.ueber:link				{ text-decoration:none; 
 					font-size:10pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold; 
 					color:black; }
  
 a.ueber:visited				{ text-decoration:none;
 					font-size:10pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;						font-weight:bold; 
 					color:black; }
 
 a.ueber:hover				{ text-decoration:none; 
 					font-size:10pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold;
 					color:red; }
 
 a.ueber:active				{ text-decoration:none; 
 					font-size:10pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold; 
 					color:red; }
 
 a.weiss:link				{ text-decoration:none; 
 					font-size:12pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold; 
 					color:white; }
  
 a.weiss:visited				{ text-decoration:none;
 					font-size:12pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;						font-weight:bold; 
 					color:white; }
 
 a.weiss:hover				{ text-decoration:none; 
 					font-size:12pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold;
 					color:red; }
 
 a.weiss:active				{ text-decoration:none; 
 					font-size:12pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold; 
 					color:red; }
 
 a:link					{ text-decoration:none; 
 					font-weight:bold; 
 					color:blue; }
  
 a:visited				{ text-decoration:none; 
 					font-weight:bold; 
 					color:blue; }
 
 a:hover					{ text-decoration:none; 
 					font-weight:bold;
 					color:red; }
 
 a:active				{ text-decoration:none; 
 					font-weight:bold; 
 					color:red; }
 
 .tooltip				{
 					position: absolute;
 					display: none;
 					font-family:Helvetica,Arial,sans-serif;
 					background-color: #FFFFFF; }
 
 .tooltip2				{
 					position: absolute;
 					display: none;
 					font-family:Helvetica,Arial,sans-serif;
 					background-color: #FFFFFF;
 					border-width: 1px;
 					border-style: solid;
 					border-color: #000000;
 					padding: 2px; }
 
 .tooltip2				.head{
 					font-family:Helvetica,Arial,sans-serif;
 					background-color: #009933;
 					color: white;
 					font-weight: bold;
 					padding: 2px; }
 
 .tooltip2				.content{
 					font-family:Helvetica,Arial,sans-serif;
 					color: 000066;
 					font-size: 10px;
 					border-size: 4px; }
 
 .tooltip2				.content td{
 					font-family:Helvetica,Arial,sans-serif;
 					width: 50%;
 					font-size: 10px;
 					text-align: center; }
 
 
 
 
 
/*]]>*/
</style><h1>Unterk&uuml;nfte</h1>
<p>Derzeit k&ouml;nnen wir Ihnen leider kein Privat-Zimmer anbieten.</p>
<p>zur<a href="http://www.sankt-andreasberg.com/andreasberg/de/text/datenbank.html"> Vermieterdatenbank</a></p></body></html>