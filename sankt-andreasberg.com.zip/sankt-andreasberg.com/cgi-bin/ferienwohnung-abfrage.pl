<?xml version="1.0" encoding="iso-8859-1"?>
<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US" xml:lang="en-US"><head><title>Untitled Document</title>
</head><body bgcolor="white" text="black"><style type="text/css">
/*<![CDATA[*/
 body {
  background-color: #FFFFFF;
 }
 p.abs					{ margin-top:120px; }
 
 p.keinabs				{ margin-top:-10pt;
 					margin-left:-10pt;
 					margin-right:-10pt; }
 
 p.navi					{ margin-top:50px; }
 
 p,blockquote,caption,dl,table		{ font-size:10pt;
 					line-height:12pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black; }
 
 p.gro					{ font-size:14pt;
 					line-height:16pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black; }
 
 li.gro					{ font-size:14pt;
 					line-height:16pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black; }
 
 table.gro				{ font-size:14pt;
 					line-height:16pt;
 					font-family:Helvetica,Arial,sans-serif;
 					margin-left:0pt;
 					color:black; }
 
 p.date					{ font-size:10pt;
 					font-style:italic;
 					line-height:12pt;
 					font-family:Helvetica,Arial,sans-serif;
 					text-align:center;
 					color:black; }
 
 p.center				{ text-align:center; }
 
 li					{ font-size:10pt;
 					line-height:12pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black;
 					margin-bottom:10pt; }
 
 h1					{ font-size:14pt;
 					text-align:center;
 					font-weight:bold;
 					margin-right:20px;
 					line-height:16pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black; }
 
 h2					{ font-size:12pt;
 					text-align:center;
 					font-weight:bold;
 					margin-right:20px;
 					line-height:14pt;
 					font-family:Helvetica,Arial,sans-serif;
 					color:black; }
 
 a.ueber:link				{ text-decoration:none; 
 					font-size:10pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold; 
 					color:black; }
  
 a.ueber:visited				{ text-decoration:none;
 					font-size:10pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;						font-weight:bold; 
 					color:black; }
 
 a.ueber:hover				{ text-decoration:none; 
 					font-size:10pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold;
 					color:red; }
 
 a.ueber:active				{ text-decoration:none; 
 					font-size:10pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold; 
 					color:red; }
 
 a.weiss:link				{ text-decoration:none; 
 					font-size:12pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold; 
 					color:white; }
  
 a.weiss:visited				{ text-decoration:none;
 					font-size:12pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;						font-weight:bold; 
 					color:white; }
 
 a.weiss:hover				{ text-decoration:none; 
 					font-size:12pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold;
 					color:red; }
 
 a.weiss:active				{ text-decoration:none; 
 					font-size:12pt;
 					line-height:20pt;
 					font-family:Helvetica,Arial,sans-serif;
 					font-weight:bold; 
 					color:red; }
 
 a:link					{ text-decoration:none; 
 					font-weight:bold; 
 					color:blue; }
  
 a:visited				{ text-decoration:none; 
 					font-weight:bold; 
 					color:blue; }
 
 a:hover					{ text-decoration:none; 
 					font-weight:bold;
 					color:red; }
 
 a:active				{ text-decoration:none; 
 					font-weight:bold; 
 					color:red; }
 
 .tooltip				{
 					position: absolute;
 					display: none;
 					font-family:Helvetica,Arial,sans-serif;
 					background-color: #FFFFFF; }
 
 .tooltip2				{
 					position: absolute;
 					display: none;
 					font-family:Helvetica,Arial,sans-serif;
 					background-color: #FFFFFF;
 					border-width: 1px;
 					border-style: solid;
 					border-color: #000000;
 					padding: 2px; }
 
 .tooltip2				.head{
 					font-family:Helvetica,Arial,sans-serif;
 					background-color: #009933;
 					color: white;
 					font-weight: bold;
 					padding: 2px; }
 
 .tooltip2				.content{
 					font-family:Helvetica,Arial,sans-serif;
 					color: 000066;
 					font-size: 10px;
 					border-size: 4px; }
 
 .tooltip2				.content td{
 					font-family:Helvetica,Arial,sans-serif;
 					width: 50%;
 					font-size: 10px;
 					text-align: center; }
 
 
 
 
 
/*]]>*/
</style><h1>Unterk&uuml;nfte</h1><p class="center"><img src="http://www.sankt-andreasberg.com/andreasberg/images/ferienwohnungen1.gif" alt="Ferienwohnungen" border="0"></p><p>Wenn Sie eine Liste mit allen Ferienwohnungen aus Sankt Andreasberg erhalten wollen, dr&uuml;cken Sie auf die Schaltfl&auml;che "Alle Ferienwohnungen anzeigen". Eine detailierte Abfrage mit Ihren W&uuml;nschen k&ouml;nnen Sie direkt darunter durchf&uuml;hren.<form action="http://www.sankt-andreasberg.com/cgi-bin/ferienwohnung-alle.pl">
<input type="submit" value="Alle Ferienwohnungen anzeigen"></input>
</form><h1>Suchabfrage Ferienwohnung</h1><p>Meine Ferienwohnung in Sankt Andreasberg sollte &uuml;ber folgende Ausstattung/Eigenschaften verf&uuml;gen:</p><form action="http://www.sankt-andreasberg.com/cgi-bin/ferienwohnung-antwort.pl">
<table align="center" border="0" cellpadding="5">
<tr>
<td><img src="http://www.sankt-andreasberg.com/andreasberg/images/personen.gif" alt="Personenanzahl" /></td>
<td>Personenanzahl</td><td><select name="personen"><option value="11">1 Person</option><option value="12">2 Personen</option><option value="13">Max. 3 Personen</option><option value="14">Max. 4 Personen</option><option value="15">Max. 5 Personen</option><option value="16">Max. 6 Personen</option><option value="17">Max. 7 Personen</option><option value="18">Max. 8 Personen</option><option value="19">Max. 9 Personen</option><option value="20">Max. 10 Personen</option><option value="egal" selected>egal</option>
</select></td>
</tr>
<tr>
<td><img src="http://www.sankt-andreasberg.com/andreasberg/images/schlafzimmer.gif" alt="Schlafzimmeranzahl" /></td>
<td>Schlafzimmeranzahl</td><td><select name="schlafzimmer"><option value="191">1 Schlafzimmer</option><option value="192">2 Schlafzimmer</option><option value="193">3 Schlafzimmer</option><option value="194">4 Schlafzimmer</option><option value="195">1 Schlafzimmer und 1 Wohn-/Schlafzimmer</option><option value="196">2 Schlafzimmer und 1 Wohn-/Schlafzimmer</option><option value="197">1 Schlafzimmer mit 2 Betten</option><option value="198">1 Wohn-/Schlafzimmer</option><option value="199">2 Schlafzimmer und 1 Wohnzimmer</option><option value="egal" selected>egal</option>
</select></td>
</tr>
<tr>
<td><img src="http://www.sankt-andreasberg.com/andreasberg/images/kinder.gif" alt="Kinderbett" /></td>
<td>Kinderbett</td><td><select name="kinderbett"><option value="21">Kinderbett vorhanden</option><option value="22">Zustellbett vorhanden</option><option value="23">Kinderbett/Zustellbett vorhanden</option><option value="24">keine Zustellbetten vorhanden</option><option value="egal" selected>egal</option>
</select></td>
</tr>
<tr>
<td><img src="http://www.sankt-andreasberg.com/andreasberg/images/bad.gif" alt="Sanit&auml;re Ausstattung" /></td>
<td>Sanit&auml;re Ausstattung</td><td><select name="bad"><option value="1" selected>WC/Dusche</option><option value="2">WC</option><option value="3">WC, Dusche auf dem Flur</option><option value="4">WC/Badewanne</option><option value="5">WC/Dusche auf dem Flur</option><option value="6">WC/Dusche/Badewanne</option><option value="7">2 &times; WC/Dusche</option><option value="egal">egal</option>
</select></td>
</tr>
<tr>
<td><img src="http://www.sankt-andreasberg.com/andreasberg/images/kueche.gif" alt="K&uuml;chenausstattung" /></td>
<td>K&uuml;chenausstattung</td><td><select name="kueche"><option value="121">Herd/Sp&uuml;lmaschine/Microwelle</option><option value="122">Herd/Sp&uuml;lmaschine</option><option value="123">Herd/Microwelle</option><option value="124">Herd/Backofen</option><option value="125">Herd/Backofen/Sp&uuml;lmaschine</option><option value="126">Herd/Sp&uuml;lmaschine/Microwelle/K&uuml;hl-Gefrierschrank</option><option value="130">keine K&uuml;chen-Ger&auml;te</option><option value="egal" selected>egal</option>
</select></td>
</tr>
<tr>
<td><img src="http://www.sankt-andreasberg.com/andreasberg/images/nichtraucher.gif" alt="Nichtraucherzimmer" /></td>
<td>Nichtraucher</td><td><select name="nichtraucher"><option value="41">Nichtraucher</option><option value="42">Raucher</option><option value="egal" selected>egal</option>
</select></td>
</tr>
<tr>
<td><img src="http://www.sankt-andreasberg.com/andreasberg/images/fernseher.gif" alt="Fernseher" /></td>
<td>Fernseher/Radio</td><td><select name="fernseher"><option value="31" selected>Fernseher</option><option value="32">Fernseher/Radio</option><option value="33">Radio</option><option value="34">Pay-TV</option><option value="35">SAT-TV/DVD/Radio</option><option value="36">TV/Video</option><option value="37">kein Fernseher/Radio vorhanden</option><option value="egal">egal</option>
</select></td>
</tr>
<tr>
<td><img src="http://www.sankt-andreasberg.com/andreasberg/images/telefon.gif" alt="Telefon" /></td>
<td>Telefon</td><td><select name="telefon"><option value="141">Telefon</option><option value="142">Telefon auf dem Flur</option><option value="143">Internet-Zugang</option><option value="144">kein Telefon/Internet-Zugang vorhanden</option><option value="egal" selected>egal</option>
</select></td>
</tr>
<tr>
<td><img src="http://www.sankt-andreasberg.com/andreasberg/images/balkon.gif" alt="Balkon/Terrasse" /></td>
<td>Balkon/Terrasse</td><td><select name="balkon"><option value="201">Balkon</option><option value="202">Terrasse</option><option value="203">Balkon oder Terrasse</option><option value="204">teilweise mit Balkon</option><option value="205">Balkon und Terrasse</option><option value="206">kein Balkon/Terrasse vorhanden</option><option value="egal" selected>egal</option>
</select></td>
</tr>
<tr>
<td><img src="http://www.sankt-andreasberg.com/andreasberg/images/sauna.gif" alt="Sauna im Haus" /></td>
<td>Sauna</td><td><select name="sauna"><option value="51">Sauna</option><option value="52">Solarium</option><option value="53">Sauna/Solarium</option><option value="54">Fitness-Raum</option><option value="55">Sauna/Solarium/Fitness-Raum</option><option value="56">Sauna/Fitness-Raum</option><option value="57">keine Sauna vorhanden</option><option value="egal" selected>egal</option>
</select></td>
</tr>
<tr>
<td><img src="http://www.sankt-andreasberg.com/andreasberg/images/hallenbad.gif" alt="Hallenbad im Haus" /></td>
<td>Hallenbad</td><td><select name="hallenbad"><option value="61">Hallenbad</option><option value="62">Swimming Pool</option><option value="63">kein Hallenbad/Swimming Pool</option><option value="egal" selected>egal</option>
</select></td>
</tr>
<tr>
<td><img src="http://www.sankt-andreasberg.com/andreasberg/images/waschma.gif" alt="Waschm&ouml;glichkeit" /></td>
<td>Waschm&ouml;glichkeit</td><td><select name="waschen"><option value="91">Waschmaschine</option><option value="92">Waschmaschine/Trockner</option><option value="93">Waschmaschine/Trockner/B&uuml;geleisen</option><option value="94">keine Waschm&ouml;glichkeit</option><option value="egal" selected>egal</option>
</select></td>
</tr>
<tr>
<td><img src="http://www.sankt-andreasberg.com/andreasberg/images/abstell.gif" alt="Abstellr&auml;me" /></td>
<td>Abstellr&auml;me</td><td><select name="abstell"><option value="81">Fahrradkeller</option><option value="82">Skikeller</option><option value="83">W&auml;schekeller</option><option value="84">Fahrradkeller/Skikeller</option><option value="85">Fahrradkeller/Skikeller/W&auml;schekeller</option><option value="86">keine Abstellr&auml;ume</option><option value="egal" selected>egal</option>
</select></td>
</tr>
<tr>
<td><img src="http://www.sankt-andreasberg.com/andreasberg/images/tiere.gif" alt="Haustiere" /></td>
<td>Haustiere</td><td><select name="haustiere"><option value="111">Haustiere erlaubt</option><option value="112">keine Haustiere</option><option value="egal" selected>egal</option>
</select></td>
</tr>
<tr>
<td><img src="http://www.sankt-andreasberg.com/andreasberg/images/park.gif" alt="Parkplatz" /></td>
<td>Parkplatz</td><td><select name="parken"><option value="101">Parkplatz</option><option value="102">Carport</option><option value="103">Garage</option><option value="104">keine eigenen Parkpl&auml;tze</option><option value="egal" selected>egal</option>
</select></td>
</tr>
<tr>
<td></td><td>Preis</td><td><select name="preis">
<option value="25">bis 25 &euro;</option>
<option value="35">bis 35 &euro;</option>
<option value="45">bis 45 &euro;</option>
<option value="egal" selected>egal</option>
</select></td>
</tr>
</table>
<p></p>
<p></p>
<input type="submit" value="Anfrage starten"></input>
</form><p>zur<a href="http://www.sankt-andreasberg.com/andreasberg/de/text/datenbank.html"> Vermieterdatenbank</a></p></body></html>